char *version_string = "fontconvert version 0.4";
