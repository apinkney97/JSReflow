char *version_string = "bzrto version 0.4";
