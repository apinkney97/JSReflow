char *version_string = "imagetofont version 0.4";
