"end",
"/FontBBox [-10 -10 30 30] def",
"end /Hershey exch definefont",
